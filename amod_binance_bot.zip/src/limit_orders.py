"""Place a limit order on Binance USDT-M Futures.

Usage: python src/limit_orders.py SYMBOL SIDE QUANTITY PRICE
Example: python src/limit_orders.py BTCUSDT SELL 0.001 60000
"""
import sys
from decimal import Decimal, InvalidOperation
from src.utils import create_client
from src.logger import get_logger

logger = get_logger(__name__)
SIDE_MAP = {"BUY": "BUY", "SELL": "SELL"}

def validate_args(args):
    if len(args) != 5:
        raise SystemExit("Usage: python src/limit_orders.py SYMBOL SIDE QUANTITY PRICE")
    symbol = args[1].strip().upper()
    side = args[2].strip().upper()
    qty_s = args[3].strip()
    price_s = args[4].strip()
    if side not in SIDE_MAP:
        raise SystemExit("SIDE must be BUY or SELL")
    try:
        qty = Decimal(qty_s)
        price = Decimal(price_s)
    except InvalidOperation:
        raise SystemExit("Invalid numeric input")
    if qty <= 0 or price <= 0:
        raise SystemExit("Quantity and price must be positive")
    return symbol, side, float(qty), float(price)

def place_limit_order(client, symbol, side, quantity, price):
    logger.info(f"Placing LIMIT order: {symbol} {side} {quantity} @ {price}")
    try:
        order = client.futures_create_order(
            symbol=symbol,
            side=side,
            type='LIMIT',
            timeInForce='GTC',
            quantity=quantity,
            price=price
        )
        logger.info(f"Order response: {order}")
        return order
    except Exception as e:
        logger.exception("Failed to place limit order")
        raise

def main():
    symbol, side, quantity, price = validate_args(sys.argv)
    client = create_client()
    order = place_limit_order(client, symbol, side, quantity, price)
    print(order)

if __name__ == '__main__':
    main()
