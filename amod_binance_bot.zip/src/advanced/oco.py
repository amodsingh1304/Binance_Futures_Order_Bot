"""Simple OCO implementation for Binance Futures (simulated using two orders + polling).

Usage:
python src/advanced/oco.py SYMBOL SIDE QUANTITY TP_PRICE STOP_PRICE

Example:
python src/advanced/oco.py BTCUSDT BUY 0.001 65000 59000
"""
import sys
import time
from decimal import Decimal, InvalidOperation
from src.utils import create_client
from src.logger import get_logger

logger = get_logger(__name__)

def validate_args(args):
    if len(args) != 6:
        raise SystemExit("Usage: python src/advanced/oco.py SYMBOL SIDE QUANTITY TP_PRICE STOP_PRICE")
    symbol = args[1].strip().upper()
    side = args[2].strip().upper()
    qty_s = args[3].strip()
    tp_s = args[4].strip()
    stop_s = args[5].strip()
    try:
        qty = Decimal(qty_s)
        tp = Decimal(tp_s)
        stop = Decimal(stop_s)
    except InvalidOperation:
        raise SystemExit("Invalid numeric input")
    if qty <= 0 or tp <= 0 or stop <= 0:
        raise SystemExit("Numbers must be positive")
    return symbol, side, float(qty), float(tp), float(stop)

def place_oco(client, symbol, side, qty, tp_price, stop_price):
    # Place TP (limit) and SL (stop-market) in parallel. When one fills, cancel the other.
    logger.info(f"Placing OCO simulated orders for {symbol}")
    # Determine side mapping for TP/SL
    tp_side = 'SELL' if side.upper() == 'BUY' else 'BUY'
    sl_side = tp_side
    tp_order = client.futures_create_order(
        symbol=symbol,
        side=tp_side,
        type='LIMIT',
        timeInForce='GTC',
        quantity=qty,
        price=tp_price
    )
    logger.info(f"TP order placed: {tp_order}")
    sl_order = client.futures_create_order(
        symbol=symbol,
        side=sl_side,
        type='STOP_MARKET',
        stopPrice=stop_price,
        closePosition=False,
        quantity=qty
    )
    logger.info(f"SL order placed: {sl_order}")
    tp_id = tp_order.get('orderId')
    sl_id = sl_order.get('orderId')
    logger.info(f"Monitoring orders: TP {tp_id}, SL {sl_id}")
    # Polling loop - in production use websockets
    try:
        while True:
            tp_status = client.futures_get_order(symbol=symbol, orderId=tp_id)
            sl_status = client.futures_get_order(symbol=symbol, orderId=sl_id)
            if tp_status.get('status') == 'FILLED':
                logger.info("TP filled; cancelling SL")
                client.futures_cancel_order(symbol=symbol, orderId=sl_id)
                break
            if sl_status.get('status') == 'FILLED':
                logger.info("SL filled; cancelling TP")
                client.futures_cancel_order(symbol=symbol, orderId=tp_id)
                break
            time.sleep(2)
    except Exception:
        logger.exception("Error while monitoring OCO orders")
        raise

def main():
    symbol, side, qty, tp, stop = validate_args(sys.argv)
    client = create_client()
    place_oco(client, symbol, side, qty, tp, stop)
    print("OCO flow started (polling). Check bot.log for events.")

if __name__ == '__main__':
    main()
