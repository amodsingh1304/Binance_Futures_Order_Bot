"""Simple TWAP implementation: split a total quantity into N equal chunks across a duration.

Usage:
python src/advanced/twap.py SYMBOL SIDE TOTAL_QTY NUM_CHUNKS DURATION_SECONDS

Example:
python src/advanced/twap.py BTCUSDT BUY 0.004 4 60
"""
import sys
import time
from decimal import Decimal, InvalidOperation
from src.utils import create_client
from src.logger import get_logger

logger = get_logger(__name__)

def validate_args(args):
    if len(args) != 6:
        raise SystemExit("Usage: python src/advanced/twap.py SYMBOL SIDE TOTAL_QTY NUM_CHUNKS DURATION_SECONDS")
    symbol = args[1].strip().upper()
    side = args[2].strip().upper()
    qty_s = args[3].strip()
    chunks_s = args[4].strip()
    dur_s = args[5].strip()
    try:
        qty = Decimal(qty_s)
        chunks = int(chunks_s)
        dur = int(dur_s)
    except (InvalidOperation, ValueError):
        raise SystemExit("Invalid numeric input")
    if qty <= 0 or chunks <= 0 or dur < 0:
        raise SystemExit("Numbers must be positive")
    return symbol, side, float(qty), chunks, dur

def run_twap(client, symbol, side, total_qty, chunks, duration):
    per_chunk = total_qty / chunks
    interval = duration / chunks if chunks else 0
    logger.info(f"Running TWAP: {symbol} {side} total={total_qty} chunks={chunks} interval={interval}s")
    for i in range(chunks):
        try:
            order = client.futures_create_order(
                symbol=symbol,
                side=side,
                type='MARKET',
                quantity=round(per_chunk, 8)
            )
            logger.info(f"TWAP chunk {i+1}/{chunks} order: {order}")
        except Exception:
            logger.exception("Failed to place TWAP chunk")
        if i < chunks - 1:
            time.sleep(interval)

def main():
    symbol, side, total_qty, chunks, dur = validate_args(sys.argv)
    client = create_client()
    run_twap(client, symbol, side, total_qty, chunks, dur)
    print("TWAP completed (or attempted). Check bot.log for details.")

if __name__ == '__main__':
    main()
