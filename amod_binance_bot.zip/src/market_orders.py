"""Place a simple market order on Binance USDT-M Futures.

Usage: python src/market_orders.py SYMBOL SIDE QUANTITY
Example: python src/market_orders.py BTCUSDT BUY 0.001
"""
import sys
from decimal import Decimal, InvalidOperation
from src.utils import create_client
from src.logger import get_logger

logger = get_logger(__name__)

SIDE_MAP = {"BUY": "BUY", "SELL": "SELL"}

def validate_args(args):
    if len(args) != 4:
        raise SystemExit("Usage: python src/market_orders.py SYMBOL SIDE QUANTITY")
    symbol = args[1].strip().upper()
    side = args[2].strip().upper()
    qty_s = args[3].strip()
    if side not in SIDE_MAP:
        raise SystemExit("SIDE must be BUY or SELL")
    try:
        qty = Decimal(qty_s)
    except InvalidOperation:
        raise SystemExit("Invalid quantity")
    if qty <= 0:
        raise SystemExit("Quantity must be positive")
    return symbol, side, float(qty)

def place_market_order(client, symbol, side, quantity):
    logger.info(f"Placing MARKET order: {symbol} {side} {quantity}")
    try:
        order = client.futures_create_order(
            symbol=symbol,
            side=side,
            type='MARKET',
            quantity=quantity
        )
        logger.info(f"Order response: {order}")
        return order
    except Exception as e:
        logger.exception("Failed to place market order")
        raise

def main():
    symbol, side, quantity = validate_args(sys.argv)
    client = create_client()
    order = place_market_order(client, symbol, side, quantity)
    print(order)

if __name__ == '__main__':
    main()
