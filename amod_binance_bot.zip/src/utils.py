import os
from binance.client import Client

def create_client():
    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")
    testnet = os.getenv("BINANCE_TESTNET", "true").lower() == "true"
    if not api_key or not api_secret:
        raise ValueError("Set BINANCE_API_KEY and BINANCE_API_SECRET environment variables.")
    client = Client(api_key, api_secret, testnet=testnet)
    # python-binance sets testnet urls automatically when testnet=True for futures if available;
    # for futures USDT-M we may need to set futures_testnet base URL manually depending on library version.
    return client
