# Amod Singh - Binance Futures Order Bot

## Overview
CLI-based trading bot for Binance USDT-M Futures. Supports:
- Market orders (`market_orders.py`)
- Limit orders (`limit_orders.py`)
- (Bonus) OCO (`advanced/oco.py`)
- (Bonus) TWAP (`advanced/twap.py`)

Includes structured logging (`bot.log`), input validation, and examples.

## Setup
1. Create a Python 3.9+ virtual environment and activate it.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Create environment variables for your Binance API keys:
   ```bash
   export BINANCE_API_KEY="your_api_key"
   export BINANCE_API_SECRET="your_api_secret"
   export BINANCE_TESTNET="true"  # set to "true" to use testnet
   ```

## Usage examples
- Place a market order:
  ```bash
  python src/market_orders.py BTCUSDT BUY 0.001
  ```
- Place a limit order:
  ```bash
  python src/limit_orders.py BTCUSDT SELL 0.001 60000
  ```
- Run TWAP (split to 4 chunks over 60 seconds):
  ```bash
  python src/advanced/twap.py BTCUSDT BUY 0.004 4 60
  ```

## Notes
- The code is written to use the Binance Futures Testnet base URL when `BINANCE_TESTNET` is "true".
- This project **does not** hardcode filenames; descriptive file names are used.
- See `report.pdf` for a brief report and screenshots (placeholder).
